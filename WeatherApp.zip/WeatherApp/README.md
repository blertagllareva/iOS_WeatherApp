# Weather App #

Codable iOS app.

## Repository ##

    * [Bitbucket repository](https://)

## Developers ##

    * Blerta Krasniqi - 23/06/2019 (mm/dd/yyyy)
    * 
    
## Cocoapods ##

    * Using Alamofire
    * Using SwiftyJSON
    * Using KVNProgress
    * Using Firebase/Core
    * Using Firebase/Auth

### Pods documentation ###

    * Alamofire: https://github.com/Alamofire/Alamofire
    * SwiftyJSON: swiftyjson github
    * KVNProgress: https://github.com/AssistoLab/KVNProgress
    * Firebase: https://github.com/firebase

## Structure ##

    * Application sturcture is MVC.
    * Application use Network Manager to handle api end points and Network Requests to handle api endpoints response.
    * Applicatiom is storyboard based.

### Login/Sign Up ###

    - The standard flow of Login, Signup, Forgot Password and Reset Password
    - Login demo user: blerta@gmail.com, password: 12345678
    
### Create Account ###

    Create account only with email and password through Firebase Auth.

### Firebase admin ###
    blerrtak@gmail.com
    
### Firebase database ###
    //https://console.firebase.google.com/project/weatherapp-d905a/authentication/users

//
//  CityWeatherModel.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import Foundation

class CityWeatherModel {
    let cityName: String?
    let temperature: Double?
    let humidity: Double?
    let minTemp: Double?
    let maxTemp: Double?

    init(cityName: String, temperature: Double, humidity: Double, minTemp: Double, maxTemp: Double) {
        self.cityName = cityName
        self.temperature = temperature
        self.humidity = humidity
        self.minTemp = minTemp
        self.maxTemp = maxTemp
    }
}

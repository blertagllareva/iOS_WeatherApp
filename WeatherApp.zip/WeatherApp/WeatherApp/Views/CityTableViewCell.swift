//
//  CityTableViewCell.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import UIKit

class CityTableViewCell: UITableViewCell {

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var currentTemperatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var minTemperatureLabel: UILabel!
    @IBOutlet weak var maxTemperatureLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setupCityCell(cityName: String, temp: Double, humidity: Double, minTemp: Double, maxTemp: Double) {
        self.backgroundImage.image = UIImage(named: cityName)
        self.nameLabel.text = "\(cityName)"
        self.currentTemperatureLabel.text = "Temp: \(temp.toInt() ?? -0)°C"
        self.humidityLabel.text = "Humidity: \(humidity.toInt() ?? -0)"
        self.minTemperatureLabel.text = "Min: \(minTemp.toInt() ?? -0)°C"
        self.maxTemperatureLabel.text = "Max: \(maxTemp.toInt() ?? -0)°C"
    }
}

//
//  LoginViewController.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import KVNProgress

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Hide navigation bar
        self.navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view.
    }

    @IBAction func loginPressed(_ sender: Any) {
        guard emailTextField.text != "" else {
            showStandardAlert(view: self, title: "Required", message: "Email is required to login.")
            return
        }

        guard passwordTextField.text != "" else {
            showStandardAlert(view: self, title: "Required", message: "Password is required to login.")
            return
        }

        KVNProgress.show(withStatus: "Please wait..")
        Auth.auth().signIn(withEmail: self.emailTextField.text!, password: self.passwordTextField.text!) { (user, error) in
            KVNProgress.dismiss()
            self.passwordTextField.text = nil

            if error == nil {
                self.performSegue(withIdentifier: "Home", sender: nil)
            } else {
                //Tells the user that there is an error and then gets firebase to tell them the error
                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)

                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)

                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
}

extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            passwordTextField.becomeFirstResponder()
        } else {
            passwordTextField.resignFirstResponder()
        }

        return true
    }
}

//
//  HomeTableViewController.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {

    // Weather API Secret Key
    private let weatherApiKey = "29dde7503518239f63624f7eb82e9e6d"

    var londonCities: [String: Int] = ["London": 2643743,
                                       "Liverpool": 2644210,
                                       "Bristol": 2654675,
                                       "Birmingham": 2655603,
                                       "York": 2633352]
    var citiesWeather = [CityWeatherModel]()

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        // API CALL
        // Reload tableView
        londonCities.forEach { (arg) in

            let (_, cityID) = arg
            let parameters = ["id": String(cityID), "APPID": weatherApiKey]
            NetworkRequest.GetCityWeather(view: self, parameters: parameters, completionHandler: { (cityData) in
                self.citiesWeather.append(cityData)
                self.tableView.reloadData()
            })
        }
    }

    @IBAction func closeButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

}

extension HomeTableViewController {
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return citiesWeather.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cityCell = tableView.dequeueReusableCell(withIdentifier: "CityTableViewCell", for: indexPath) as? CityTableViewCell else { return UITableViewCell() }

        let city = citiesWeather
        let currentCity = city[indexPath.row]
        let cityName = currentCity.cityName
        let temp = currentCity.temperature
        let humidity = currentCity.humidity
        let minTemp = currentCity.minTemp
        let maxTemp = currentCity.maxTemp

        cityCell.setupCityCell(cityName: cityName!, temp: temp!, humidity: humidity!, minTemp: minTemp!, maxTemp: maxTemp!)
        return cityCell
    }
}

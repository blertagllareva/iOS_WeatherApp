//
//  NetworkRequest.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import KVNProgress

class NetworkRequest {

    class func GetCityWeather(view: UIViewController, parameters: [String : String], completionHandler:@escaping (CityWeatherModel) -> ()){

        KVNProgress.show(withStatus: "Loading Weather..")
        Alamofire.request(NetworkManager.cityWeather, method: .get, parameters: parameters).responseJSON { response in
            KVNProgress.dismiss()
            if let serverResponse = response.result.value {
                let jsonResponse = JSON(serverResponse)
                if let success = jsonResponse["cod"].int, success == 200 {
                    let weatherData = jsonResponse["main"]
                    let cityName = jsonResponse["name"].stringValue
                    let temperature = weatherData["temp"].doubleValue
                    let humidity = weatherData["humidity"].doubleValue
                    let minTemp = weatherData["temp_min"].doubleValue
                    let maxTemp = weatherData["temp_max"].doubleValue


                    let cityWeather: CityWeatherModel = CityWeatherModel(cityName: cityName,
                                                                         temperature: temperature,
                                                                         humidity: humidity,
                                                                         minTemp: minTemp,
                                                                         maxTemp: maxTemp)
                    completionHandler(cityWeather)
                } else {
                    showStandardAlert(view: view, title: "Error", message: "There was an error")
                }
            } else {
                showStandardAlert(view: view, title: "Error", message: "Failed to connect to server")
            }
        }
    }
}

//
//  NetworkManager.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import Foundation

enum NetworkManager {
    ///Base URL
    static let BASE_URL: String = APIUrl()

    ///Functions
    static let cityWeather = NetworkManager.BASE_URL
}

private func APIUrl() -> String {
    #if PRODUCTION
    return "https://"
    #else
    return "https://api.openweathermap.org/data/2.5/weather"
    #endif
}

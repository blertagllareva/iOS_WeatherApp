//
//  Helpers.swift
//  WeatherApp
//
//  Created by Blerta Krasniqi on 6/23/19.
//  Copyright © 2019 Blerta Krasniqi. All rights reserved.
//

import Foundation
import Foundation
import UIKit

// Standard iOS Alert
public func showStandardAlert(view: UIViewController, title: String, message: String){
    // Create alert view
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)

    // Create alert actions
    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

    // Present alert
    view.present(alert, animated: true, completion: nil)
}


// Extension to convert Double to Int
extension Double {
    func toInt() -> Int? {
        if self >= Double(Int.min) && self < Double(Int.max) {
            return Int(self)
        } else {
            return nil
        }
    }
}
